/* ══════════════════════════════════════════════════════════
   AUTOLUX — MAIN APPLICATION JAVASCRIPT
   Central data store, car rendering, search, booking logic
══════════════════════════════════════════════════════════ */

'use strict';

// ════════════════════════════════════════
// DATA STORE (simulates DB)
// ════════════════════════════════════════
const AutoLux = {

  // Master vehicle fleet
  vehicles: [
    {
      id: 1, name: 'BMW 5 Series', category: 'luxury', transmission: 'Automatik',
      seats: 5, fuel: 'Benzinë', pricePerDay: 120, rating: 4.9, available: true,
      img: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=600&q=80',
      features: ['GPS', 'Bluetooth', 'Klimë', 'Kamera Prapa'],
      description: 'Eksperiencë premium me BMW 5 Series. Perfekt për udhëtime biznesi dhe pushime.'
    },
    {
      id: 2, name: 'Toyota RAV4', category: 'suv', transmission: 'Automatik',
      seats: 5, fuel: 'Hibrid', pricePerDay: 75, rating: 4.7, available: true,
      img: 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=600&q=80',
      features: ['GPS', 'AWD', 'Klimë', '7 Airbags'],
      description: 'SUV hibrid me kapacitet të lartë dhe konsum minimal karburanti.'
    },
    {
      id: 3, name: 'Mercedes-Benz C-Class', category: 'luxury', transmission: 'Automatik',
      seats: 5, fuel: 'Diesel', pricePerDay: 140, rating: 4.9, available: true,
      img: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=600&q=80',
      features: ['GPS', 'Ambient Light', 'Masazh Sedilje', 'Sunroof'],
      description: 'Luksi gjerman redefinuar. Komfort i paprecedentë për çdo rrugë.'
    },
    {
      id: 4, name: 'Volkswagen Golf', category: 'economy', transmission: 'Manual',
      seats: 5, fuel: 'Benzinë', pricePerDay: 45, rating: 4.5, available: true,
      img: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?w=600&q=80',
      features: ['Klimë', 'Radio', 'USB', 'Siguri ABS'],
      description: 'Makina e përsosur ekonomike për udhëtime qyteti dhe pushime.'
    },
    {
      id: 5, name: 'Porsche 911', category: 'sports', transmission: 'Automatik',
      seats: 2, fuel: 'Benzinë', pricePerDay: 250, rating: 5.0, available: true,
      img: 'https://images.unsplash.com/photo-1580274455191-1c62238fa333?w=600&q=80',
      features: ['Launch Control', 'Sport Chrono', 'Bose Audio', 'Ventilim Sedilje'],
      description: 'Ikonë e sportivitetit. Ndie shpejtësinë dhe elegancën gjermane.'
    },
    {
      id: 6, name: 'Ford Transit', category: 'van', transmission: 'Manual',
      seats: 9, fuel: 'Diesel', pricePerDay: 85, rating: 4.4, available: true,
      img: 'https://images.unsplash.com/photo-1559416523-140ddc3d238c?w=600&q=80',
      features: ['GPS', 'Klimë', '9 Ulëse', 'Bagazhier i madh'],
      description: 'Ideale për grupe dhe transferta kolektive. Kapacitet maksimal.'
    },
    {
      id: 7, name: 'Audi Q5', category: 'suv', transmission: 'Automatik',
      seats: 5, fuel: 'Diesel', pricePerDay: 100, rating: 4.8, available: false,
      img: 'https://images.unsplash.com/photo-1606220588907-f3e42c2cc95f?w=600&q=80',
      features: ['Quattro AWD', 'Virtual Cockpit', 'Panoramik', 'Klimë 3-Zone'],
      description: 'Teknologji e avancuar Audi me quattro drive për çdo terren.'
    },
    {
      id: 8, name: 'Ford Mustang', category: 'sports', transmission: 'Manual',
      seats: 4, fuel: 'Benzinë', pricePerDay: 160, rating: 4.7, available: true,
      img: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=600&q=80',
      features: ['V8 Engine', 'Sport Mode', 'Subwoofer', 'Launch Control'],
      description: 'Ikona amerikane e fuqisë. Ngjyr e zjarrtë, zë i thellë V8.'
    },
    {
      id: 9, name: 'Renault Clio', category: 'economy', transmission: 'Manual',
      seats: 5, fuel: 'Benzinë', pricePerDay: 35, rating: 4.3, available: true,
      img: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?w=600&q=80',
      features: ['Klimë', 'Bluetooth', 'USB', 'Sensora Parkimi'],
      description: 'Zgjidhja ideale për buxhete të arsyeshme pa kompromis komforti.'
    }
  ],

  // Bookings store (local persistence)
  getBookings() {
    return JSON.parse(localStorage.getItem('autolux_bookings') || '[]');
  },
  saveBookings(bookings) {
    localStorage.setItem('autolux_bookings', JSON.stringify(bookings));
  },
  addBooking(booking) {
    const bookings = this.getBookings();
    bookings.push(booking);
    this.saveBookings(bookings);
    return booking;
  },

  // Double-booking protection
  isCarAvailableForDates(carId, startDate, endDate, excludeBookingId = null) {
    const bookings = this.getBookings();
    const start = new Date(startDate);
    const end = new Date(endDate);
    return !bookings.some(b => {
      if (b.carId !== carId) return false;
      if (b.id === excludeBookingId) return false;
      if (['cancelled', 'finished'].includes(b.status)) return false;
      const bStart = new Date(b.startDate);
      const bEnd = new Date(b.endDate);
      return start < bEnd && end > bStart; // overlap check
    });
  },

  // Generate unique ID
  generateId() {
    return 'AL' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substr(2, 4).toUpperCase();
  },

  // Days calculation
  calcDays(start, end) {
    const s = new Date(start), e = new Date(end);
    return Math.max(1, Math.ceil((e - s) / (1000 * 60 * 60 * 24)));
  },

  // Total price
  calcTotal(pricePerDay, days) {
    let total = pricePerDay * days;
    if (days >= 7) total *= 0.92; // 8% discount for week+
    else if (days >= 3) total *= 0.9; // 10% discount for 3+ days
    return Math.round(total * 100) / 100;
  },

  // Format currency
  formatPrice(amount) {
    return `€${amount.toLocaleString('en', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  },

  // Format date
  formatDate(dateStr) {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('sq-AL', { day: '2-digit', month: 'short', year: 'numeric' });
  }
};

// ════════════════════════════════════════
// UI UTILITIES
// ════════════════════════════════════════
const UI = {
  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container') || (() => {
      const div = document.createElement('div');
      div.id = 'toast-container';
      document.body.appendChild(div);
      return div;
    })();
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type]||'ℹ️'}</span><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 400);
    }, 4000);
  },

  openModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.add('open');
  },

  closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.remove('open');
  },

  setLoading(btn, loading) {
    if (!btn) return;
    if (loading) {
      btn.setAttribute('data-original', btn.innerHTML);
      btn.innerHTML = '<div class="spinner"></div>';
      btn.disabled = true;
    } else {
      btn.innerHTML = btn.getAttribute('data-original') || btn.innerHTML;
      btn.disabled = false;
    }
  },

  validate(fields) {
    let valid = true;
    fields.forEach(({ el, msg, check }) => {
      const errorEl = el.parentElement.querySelector('.form-error');
      const isOk = check ? check(el.value) : !!el.value.trim();
      if (!isOk) {
        valid = false;
        el.classList.add('error');
        if (errorEl) { errorEl.textContent = msg; errorEl.classList.add('show'); }
      } else {
        el.classList.remove('error');
        if (errorEl) errorEl.classList.remove('show');
      }
    });
    return valid;
  }
};

// ════════════════════════════════════════
// NAVBAR
// ════════════════════════════════════════
(function initNavbar() {
  const navbar = document.getElementById('navbar');
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');

  window.addEventListener('scroll', () => {
    if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 40);
  });

  if (hamburger) {
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
  }

  // Close menu on link click
  if (navLinks) {
    navLinks.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  // Set active nav link
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href').split('/').pop();
    link.classList.toggle('active', href === currentPage);
  });
})();

// ════════════════════════════════════════
// HOME PAGE — Fleet Filter & Display
// ════════════════════════════════════════
(function initHomePage() {
  const grid = document.getElementById('carsGrid');
  if (!grid) return;

  let currentFilter = 'all';
  let currentSort = 'default';
  let filteredCars = [...AutoLux.vehicles];

  function renderCars() {
    let cars = [...AutoLux.vehicles];

    // Filter
    if (currentFilter !== 'all') {
      cars = cars.filter(c => c.category === currentFilter);
    }

    // Sort
    if (currentSort === 'price-asc') cars.sort((a, b) => a.pricePerDay - b.pricePerDay);
    else if (currentSort === 'price-desc') cars.sort((a, b) => b.pricePerDay - a.pricePerDay);
    else if (currentSort === 'name') cars.sort((a, b) => a.name.localeCompare(b.name));

    // Only show first 6 on home
    cars = cars.slice(0, 6);
    filteredCars = cars;

    grid.innerHTML = '';
    cars.forEach((car, i) => {
      const card = createCarCard(car);
      card.style.animationDelay = `${i * 0.06}s`;
      card.classList.add('fade-in');
      grid.appendChild(card);
    });

    if (cars.length === 0) {
      grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--text-muted)">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" style="margin:0 auto 16px;display:block;opacity:0.3"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <p>Nuk u gjet asnjë makinë me këto filtra</p>
      </div>`;
    }
  }

  function createCarCard(car) {
    const card = document.createElement('div');
    card.className = 'car-card';
    card.setAttribute('data-car-id', car.id);
    const specs = [
      `<span class="car-spec"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22V12M12 12C12 12 7 9 7 5a5 5 0 0110 0c0 4-5 7-5 7z"/></svg>${car.transmission}</span>`,
      `<span class="car-spec"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>${car.seats} vende</span>`,
      `<span class="car-spec"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 22V8l9-6 9 6v14"/><path d="M10 22v-6h4v6"/></svg>${car.fuel}</span>`
    ];
    card.innerHTML = `
      <div class="car-img-wrap">
        <img src="${car.img}" alt="${car.name}" loading="lazy" />
        <span class="car-badge ${car.available ? 'badge-available' : 'badge-booked'}">
          ${car.available ? 'Available' : 'Booked'}
        </span>
        <button class="car-fav" title="Favorite" onclick="toggleFav(this,${car.id})">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
        </button>
      </div>
      <div class="car-body">
        <div class="car-category">${car.category.toUpperCase()}</div>
        <div class="car-name">${car.name}</div>
        <div class="car-specs">${specs.join('')}</div>
        <div class="car-footer">
          <div class="car-price">
            <span class="price-amount">${AutoLux.formatPrice(car.pricePerDay)}</span>
            <span class="price-unit">/ ditë</span>
          </div>
          <a href="src/pages/booking.html?car=${car.id}" class="btn-book">
            Rezervo
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </a>
        </div>
      </div>`;
    return card;
  }

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      renderCars();
    });
  });

  // Sort
  const sortEl = document.getElementById('sortCars');
  if (sortEl) {
    sortEl.addEventListener('change', () => {
      currentSort = sortEl.value;
      renderCars();
    });
  }

  // Search button
  const searchBtn = document.getElementById('searchBtn');
  if (searchBtn) {
    searchBtn.addEventListener('click', () => {
      const loc = document.getElementById('pickupLocation')?.value;
      const cat = document.getElementById('carCategory')?.value;
      const start = document.getElementById('pickupDate')?.value;
      const end = document.getElementById('returnDate')?.value;

      if (!loc) { UI.showToast('Zgjidhni vendndodhjen e marrjes', 'warning'); return; }
      if (!start) { UI.showToast('Zgjidhni datën e nisjes', 'warning'); return; }
      if (!end) { UI.showToast('Zgjidhni datën e kthimit', 'warning'); return; }
      if (new Date(end) <= new Date(start)) {
        UI.showToast('Data e kthimit duhet të jetë pas datës së nisjes', 'error'); return;
      }

      const params = new URLSearchParams({ loc, cat: cat || '', start, end });
      window.location.href = `src/pages/fleet.html?${params.toString()}`;
    });
  }

  // Set default dates
  const today = new Date();
  const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
  const nextWeek = new Date(today); nextWeek.setDate(nextWeek.getDate() + 8);
  const toISO = d => d.toISOString().split('T')[0];
  const pickupEl = document.getElementById('pickupDate');
  const returnEl = document.getElementById('returnDate');
  if (pickupEl) pickupEl.value = toISO(tomorrow);
  if (returnEl) returnEl.value = toISO(nextWeek);
  if (pickupEl) pickupEl.min = toISO(today);
  if (returnEl) returnEl.min = toISO(tomorrow);

  renderCars();
})();

// ════════════════════════════════════════
// GLOBAL: Favorite toggle
// ════════════════════════════════════════
function toggleFav(btn, carId) {
  btn.classList.toggle('active');
  const isFav = btn.classList.contains('active');
  btn.innerHTML = isFav
    ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="var(--red)" stroke="var(--red)" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>`
    : `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>`;
  UI.showToast(isFav ? 'Shtuar te të preferuarat ❤️' : 'Hequr nga të preferuarat', isFav ? 'success' : 'info');
}

// ════════════════════════════════════════
// SCROLL ANIMATIONS (Intersection Observer)
// ════════════════════════════════════════
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.step-card, .testimonial-card, .car-card, .feature-strip-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });
});

// Expose globally
window.AutoLux = AutoLux;
window.UI = UI;
